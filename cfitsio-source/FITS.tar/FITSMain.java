
import java.io.*;
import java.lang.Integer;
import java.lang.System;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.*;
import javax.swing.table.*;


public class FITSMain extends JPanel {
	//
	//	WHY IS THIS NOT "TableModel model = new FITSTableModel();" ?????
	//
	static final FITSTableModel model = new FITSTableModel();
	final FITSCellEditor editor = new FITSCellEditor();
	static final JTable table = new JTable(model);

	public FITSMain () {
                JTabbedPane tabbedPane = new JTabbedPane();

                /**********************************************************************************/
                JPanel panel4 = new JPanel();

                panel4.setLayout(new BoxLayout(panel4, BoxLayout.Y_AXIS));
                panel4.setBorder(BorderFactory.createEmptyBorder(10,5,10,5));

                String[] columnNames = {"Keyword","Value"};
		model.setColumnIdentifiers( columnNames );

		addRow ( "BITPIX", new String[] {""});         //COMPUTED
		addRow ( "NAXIS1", new String[] {""} );
		addRow ( "NAXIS2", new String[] {""});
		addRow ( "DATE", new String[] {""});
		addRow ( "DATE_OBS", new String[] {""});
		addRow ( "FILEORIG", new String[] {""});
		addRow ( "FILENAME", new String[] {""});
		addRow ( "SUMTYPE", new String[] {"CCD"});
		addRow ( "VERSION", new String[] {"yymmdd"});
		addRow ( "COMMENT", new String[] {"FITS coordinates for center of 1024x1024 image are [512.5, 512.5]"});
		addRow ( "COMMENT", new String[] {"DATE-OBS is equal to .img file last-modified date"});

		table.setRowHeight(25);
		table.getColumnModel().getColumn(1).setCellEditor( editor );
		table.getColumnModel().getColumn(0).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setPreferredWidth(400);

                JButton buttonC = new JButton( "Add Comment" );
                buttonC.addActionListener( new ActionListener()
                {       public void actionPerformed(ActionEvent e)
                        {
                                FITSTableModel model = (FITSTableModel)table.getModel();
                                addRow ( "COMMENT", new String[] {"A", "B", "C"} );
                        }
                });

                table.setPreferredScrollableViewportSize(new Dimension(500, 70));

		addRow ( "Comment", new String[] { "1", "2", "3" } );
		addRow ( "Camera", new String[] { "Talktronics", "RAL", "Other" } );
		addRow ( "Instrument", new String[] { "EUVI", "HI1", "HI2" } );
		addRow ( "Test Single Entry", new String[] { "just this one" } );

                JScrollPane scrollPane = new JScrollPane( table );
                panel4.add( scrollPane );
                panel4.add( buttonC );

                tabbedPane.addTab ("Testing Tables", panel4);

                setLayout(new GridLayout(1, 1)); 
                add(tabbedPane);
        }

	public void addRow ( String key, String[] values ) {
		//	
		// Perhaps it would be better to pass the model and editor as params
		// as opposed to making them class variable
		//	
		model.addRow ( new Object[] { key, values[0] } );
		editor.addRow ( values );
	}

        public static void main(String[] args) {
                JFrame frame = new JFrame("FITSMain");
                frame.addWindowListener(new WindowAdapter() {
                        public void windowClosing(WindowEvent e) {
				int i;
				for ( i=0; i<table.getRowCount(); i++ ) {
					System.out.println ( table.getValueAt ( i, 0 ) + " -- " + table.getValueAt ( i, 1 ) );
				}
                                System.exit(0);
                        }
                });
                frame.getContentPane().add(new FITSMain(), 
                        BorderLayout.CENTER);
                frame.setSize(600, 400);
                frame.setVisible(true);
	}
}

