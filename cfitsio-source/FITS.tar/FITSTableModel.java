
import java.io.*;
import java.lang.Integer;
import java.lang.System;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.*;
import javax.swing.table.*;
//import javax.swing.event.TableModelEvent;
//import javax.swing.event.TableModelListener;


class FITSTableModel extends DefaultTableModel { // implements TableModel, TableModelListener {

	FITSTableModel(Object[][] data, Object[] columnNames) {
		super ( data, columnNames );
	}

	FITSTableModel () {
		super ();
	}

	public boolean isCellEditable(int row, int col) {
		//Note that the data/cell address is constant,
		//no matter where the cell appears onscreen.
		if (col < 1)  { 
			return false;
		} else {
			return true;
		}
	}
//
//public void addTableModelListener(TableModelListener l){}
//public Class getColumnClass(int columnIndex){ return super.getColumnClass(columnIndex); }
//public int getColumnCount(){ return super.getColumnCount(); }
//public String getColumnName(int columnIndex){ return super.getColumnName( columnIndex ); }
//public int getRowCount(){ return super.getRowCount(); }
//public Object getValueAt(int rowIndex, int columnIndex){ return super.getValueAt (rowIndex, columnIndex); }
//public void removeTableModelListener(TableModelListener l){}
//public void setValueAt(Object aValue, int rowIndex, int columnIndex){}
//
//public void tableChanged(TableModelEvent e) {}
//    
}


